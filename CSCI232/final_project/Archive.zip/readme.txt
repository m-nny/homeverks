Changes to the project. 26.05.18
Project has been implemented almost fully. Only some special error handlings, timeout, and later quiz behavior is left undone.

Changes:
Main plan and direction of the project remained the same, however some functions are kept unused, and thus unimplemented.
Minor changes to name of functions and variables

Added some helper functions like set_string(), parse_question(), parse_quiz(), read_quiz().

Added some handlers for command from client: handle_create_group()

Implemented group_thread(), which is responsible for the quiz part. Actually, it is not finished, but main functionality is here.